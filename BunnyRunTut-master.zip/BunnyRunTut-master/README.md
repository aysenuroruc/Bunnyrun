# BunnyRunTut
This is the source code for the "Run Bunny, Run!" creating a 2D game in Unity tutorial.

Check out http://www.rabidgremlin.com/runbunnyrun/ for more information or 

watch the video tutorials here: https://www.youtube.com/playlist?list=PLvUqRm2B9RRBgJipfDmFR7sFhEwBn7aGT
