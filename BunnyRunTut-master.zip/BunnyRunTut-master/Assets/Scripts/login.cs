﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.Text.RegularExpressions;
using UnityEngine.SceneManagement;
using System.Security.Cryptography;

public class login : MonoBehaviour
{
    public GameObject username;
    public GameObject password;
    private string Username;
    private string Password;
    public string DecyptedPassword;
    private string form;
    public String[] Lines;
    /* private string[] Characters = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "y", "z", "x" , "w",
         "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P","Q","R", "S", "T", "U", "V", "Y", "Z", "X", "W",
     "1", "2", "3", "4", "5", "6", "7", "8", "9" }; */

    public void LoginButton()
    {
        bool UN = false;
        bool PW = false;
        if (Username != "")
        {
            if (System.IO.File.Exists(@"F:\UnityRegisterTest\" + Username + ".txt"))
            {
                UN = true;
                Lines = System.IO.File.ReadAllLines(@"F:\UnityRegisterTest\" + Username + ".txt");
            }
            else
            {
                Debug.LogWarning("Username invalid");
            }
        }
        else
        {
            Debug.LogWarning("Username Field Empty");
        }
        if (Password != "") {
            if (System.IO.File.Exists(@"F:\UnityRegisterTest\" + Username + ".txt"))
            {
                int i = 1;
                foreach (char c in Lines[2])
                {
                    i++;
                    char DecryptedPassword = (char)(c * i);
                    Password += DecryptedPassword.ToString();
                }
                if (Password == DecyptedPassword) {
                    PW = true;
                }
                else
                {
                    Debug.LogWarning("Password is invalid-a");
                }
            }
            else
            {
                Debug.LogWarning("Password is invalid-b");
            }
        }
        else {
            Debug.LogWarning("Password Field Empty");
        }
        if(UN == true&& PW == true)
        {
            username.GetComponent<InputField>().text = "";
            password.GetComponent<InputField>().text= "";
            print ("login succes");
            SceneManager.LoadScene("Start Menü");
           // Application.LoadLevel("Start Menü"); Anymore doesnt using this
        }
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.Tab))
        {
            if (username.GetComponent<InputField>().isFocused)
            {
                password.GetComponent<InputField>().Select();
            }
        }
        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (Username != "" && Password != "")
            {
                LoginButton();
            }
        }
        Username = username.GetComponent<InputField>().text;
        Password = password.GetComponent<InputField>().text;
    }
}
 

 
